from flask import Flask, request, jsonify
import os
import psycopg2

app = Flask(__name__)

# Define o modelo de Cliente
class Cliente:
    def __init__(self, _id, nome, sobreNome):
        self._id = _id
        self.nome = nome
        self.sobreNome = sobreNome


# Função para conectar ao banco de dados
def conectar():
    DB_URL = os.environ.get('DATABASE_URL')
    db = psycopg2.connect(DB_URL, sslmode='require')
    return db


@app.route('/clientes', methods=['GET'])
def clientes():
    try:
        db = conectar()
        cur = db.cursor()
        cur.execute('SELECT * FROM cliente')
        todos_clientes = cur.fetchall()
        
        for i, cliente in enumerate(todos_clientes):
            todos_clientes[i] = Cliente(cliente[1], cliente[2], cliente[3])
        
        response = jsonify([cliente.__dict__ for cliente in todos_clientes])

        return response, 200
    except:
        return jsonify({'mensagem': 'Erro ao buscar clientes'}), 500


@app.route('/clientes/<int:id>', methods=['GET'])
def get_cliente(id):
    try:
        db = conectar()
        cur = db.cursor()
        cur.execute('SELECT * FROM cliente WHERE _id = %s', (id,))
        cliente = cur.fetchone()
        
        if cliente is None:
            return jsonify({'mensagem': 'Cliente não encontrado'}), 404

        cliente = Cliente(cliente[1], cliente[2], cliente[3])

        return jsonify([cliente.__dict__]), 200
    except:
        return jsonify({'mensagem': 'Erro ao buscar cliente'}), 500


@app.route('/clientes', methods=['POST'])
def post_cliente():
    info = request.get_json()
    try:
        db = conectar()
        cur = db.cursor()
        cur.execute('INSERT INTO cliente (nome, sobrenome) VALUES (%s, %s)', (info['nome'], info['sobreNome']))
        db.commit()
        cur.close()
        db.close()
        return '', 200
    except:
        return jsonify({'mensagem': 'Erro ao inserir cliente'}), 500


@app.route('/clientes', methods=['PUT'])
def put_cliente():
    info = request.get_json()
    if '_id' not in info:
        return jsonify({'mensagem': '_id é obrigatório'}), 400

    try:
        db = conectar()
        cur = db.cursor()
        cur.execute('SELECT * FROM cliente WHERE _id = %s', (info['_id'],))
        registro = cur.fetchone()
        
        if registro is None:
            return jsonify({'mensagem': 'Cliente não encontrado'}), 404

        cliente = Cliente(registro[1], registro[2], registro[3])

        for key, value in info.items():
            if key not in cliente.__dict__:
                return jsonify({'mensagem': f'{key} não é um campo válido'}), 400

            if key != '_id':
                setattr(cliente, key, value)
        
        cur.execute('UPDATE cliente SET nome = %s, sobrenome = %s WHERE _id = %s', (cliente.nome, cliente.sobreNome, cliente._id))

        db.commit()
        cur.close()
        db.close()

        return jsonify([cliente.__dict__]), 200
    
    except:
        return jsonify({'mensagem': 'Erro ao atualizar cliente'}), 500


@app.route('/clientes', methods=['DELETE'])
def delete_cliente():
    try:
        info = request.get_json()
    except:
        return jsonify({'mensagem': 'Corpo da requisição incorreto'}), 400

    if '_id' not in info:
        return jsonify({'mensagem': '_id é obrigatório'}), 400
    
    try:
        db = conectar()
        cur = db.cursor()
        cur.execute('SELECT * FROM cliente WHERE _id = %s', (info['_id'],))
        registro = cur.fetchone()
        
        if registro is None:
            return jsonify({'mensagem': 'Cliente não encontrado'}), 404

        cur.execute('DELETE FROM cliente WHERE _id = %s', (info['_id'],))
        db.commit()
        cur.close()
        db.close()

        cliente = Cliente(registro[1], registro[2], registro[3])

        return jsonify([cliente.__dict__]) , 200

    except:
        return jsonify({'mensagem': 'Erro ao deletar cliente'}), 500


@app.route('/clientes/<int:id>', methods=['DELETE'])
def delete_cliente_id(id):
    try:
        db = conectar()
        cur = db.cursor()
        cur.execute('SELECT * FROM cliente WHERE _id = %s', (id,))
        registro = cur.fetchone()
        
        if registro is None:
            return jsonify({'mensagem': 'Cliente não encontrado'}), 404

        cur.execute('DELETE FROM cliente WHERE _id = %s', (id,))
        db.commit()
        cur.close()
        db.close()

        cliente = Cliente(registro[1], registro[2], registro[3])

        return jsonify([cliente.__dict__]) , 200

    except:
        return jsonify({'mensagem': 'Erro ao deletar cliente'}), 500