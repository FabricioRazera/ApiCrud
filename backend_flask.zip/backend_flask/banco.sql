CREATE TABLE cliente (
	pk SERIAL PRIMARY KEY,
	_id SERIAL UNIQUE,
	nome VARCHAR(50),
	sobreNome VARCHAR(50)
);

SELECT * FROM cliente;

INSERT INTO cliente (id, nome, sobreNome) VALUES (0, 'Carlos', 'Costa');

